var searchData=
[
  ['is_5fexpelled',['is_expelled',['../classCustomer.html#a3e92e2a432cae9c8b121d5b906183e12',1,'Customer']]]
];
