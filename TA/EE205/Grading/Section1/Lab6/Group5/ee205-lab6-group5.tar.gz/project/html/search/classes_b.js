var searchData=
[
  ['pluralise',['pluralise',['../structCatch_1_1pluralise.html',1,'Catch']]]
];
