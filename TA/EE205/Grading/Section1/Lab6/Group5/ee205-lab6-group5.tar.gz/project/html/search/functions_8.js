var searchData=
[
  ['take_5forder',['take_order',['../classCustomer.html#a8ce88d5e5b4684de4617af486abb64e1',1,'Customer']]]
];
