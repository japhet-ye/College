var searchData=
[
  ['regexmatcher',['RegexMatcher',['../structCatch_1_1Matchers_1_1StdString_1_1RegexMatcher.html',1,'Catch::Matchers::StdString']]],
  ['registrarfortagaliases',['RegistrarForTagAliases',['../structCatch_1_1RegistrarForTagAliases.html',1,'Catch']]],
  ['resultdisposition',['ResultDisposition',['../structCatch_1_1ResultDisposition.html',1,'Catch']]],
  ['resultwas',['ResultWas',['../structCatch_1_1ResultWas.html',1,'Catch']]],
  ['reusablestringstream',['ReusableStringStream',['../classCatch_1_1ReusableStringStream.html',1,'Catch']]]
];
