var indexSectionsWithContent =
{
  0: "abcdegiklmnoprstuw",
  1: "abcdeiklmnoprstuw",
  2: "cegioprst",
  3: "o",
  4: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Friends",
  4: "Pages"
};

