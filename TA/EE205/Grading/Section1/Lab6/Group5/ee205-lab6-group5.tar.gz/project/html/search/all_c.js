var searchData=
[
  ['pluralise',['pluralise',['../structCatch_1_1pluralise.html',1,'Catch']]],
  ['prepare_5fdish',['prepare_dish',['../classCook.html#ab04c03a35f4ea5ca4913fc9d10cbf076',1,'Cook::prepare_dish()'],['../classKitchen.html#aaaa4abc7bd9982085c161c01042653c2',1,'Kitchen::prepare_dish()']]]
];
