#include"leap.h"
#include<stdio.h>
int julian_date ( int day, int month, int year);
//This function calculates the julain date of a certain date
