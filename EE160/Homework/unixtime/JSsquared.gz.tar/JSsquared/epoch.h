double secs_since_epoch( int day, int month, int year, int hour, int minute, int seconds);
