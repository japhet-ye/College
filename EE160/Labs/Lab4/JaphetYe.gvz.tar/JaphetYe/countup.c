//Japhet Ye
//September 14, 2016
//J Sqaured
//This program counts up from 1 until 10

#include<stdio.h>

int main()

{

	int c = 0;

	while ( c < 10) {

	c = c + 1;

	printf("%d \n", c);

	}

	return 0;

	


}

	
