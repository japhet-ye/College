//myinfo.c
//Japhet Ye
//japhetye@hawaii.edu
//Japhet and Jin's group
//1 September, 2016
//required program

#include<stdio.h>

int main()
{
	printf("Japhet Ye\njaphetye@hawaii.edu\n"
		"Japhet and Jin's group\n");
	return 0;
}


