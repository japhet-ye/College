//pay0.c
//Japhet Ye
//japhetye@hwaii.edu
//Japhet and Jin's group
//pay program
//1 September, 2016

#include<stdio.h>

int main()
{

	
	printf("Pay Calculation\n");
	
	printf("Enter ID Number\n");
	scanf("id_number=%lf", &id_number);

	double id_number;

	printf("Input Hours Worked\n");
	scanf("hours_worked=%lf", &hours_worked);

	double hours_worked;

	printf("Input Rate of Pay\n");
	scanf("rate_of_pay=%lf", &rate_of_pay);

	double rate_of_pay

	pay = hours_worked * rate_of_pay;

	double pay

	printf("ID Number = %d\n", id_number);
	printf("Pay = %lf\n", pay);

}

