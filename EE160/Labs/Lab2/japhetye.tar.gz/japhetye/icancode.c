//icancode.c
//Japhet Ye
//japhetye@hawaii.edu
//Japhet and Jin's group
//1 September, 2016
//required program

#include<stdio.h>

int main()
{
	printf("Hello Japhet!\nThis is the second lab!\n");
	return 0;
}


