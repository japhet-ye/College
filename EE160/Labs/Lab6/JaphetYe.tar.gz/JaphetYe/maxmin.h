float max( float n1, float n2 );
//This function returns the greater of the two numbers
float min ( float n1, float n2 );
//This function return the lesser of two numbers

